import sys
from subprocess import Popen, PIPE
import re

#==============================================================================#
# This tools sets the generic configuration of the supplied environment
#==============================================================================#

def assert_method(env, condition, message, code=1):
    if not condition:
        sys.stdout.flush()
        sys.stderr.write('\n' + '*'*79 + '\n')
        sys.stderr.write("BUILD FAILED! %s\n" % message)
        sys.stderr.write('*'*79 + '\n\n')
        sys.stderr.flush()
        env.Exit(code)

def generate(env):
    # Make the compilation output a bit nicer
    env['ASCOMSTR'] = 'Assembling $SOURCE:\n $ASCOM'
    env['CCCOMSTR'] = 'Compiling $SOURCE: \n $CCCOM'
    env['LINKCOMSTR'] = 'Linking $TARGET: \n $LINKCOM'
    env['ARCOMSTR'] = 'Creating library $TARGET'
    env['QACCOMSTR'] = 'Analyzing $SOURCE'
    env['ROMCRCCOMSTR'] = 'Calculating CRC and modifying $TARGET'
        
    # Make the compilation decision a bit faster.
    env.Decider('MD5-timestamp')

    env.AddMethod(assert_method, 'Assert')

    
def exists(env):
    return True

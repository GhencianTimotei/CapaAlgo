""" Wrapper for SCons.Tool.mingw
"""
import os
import SCons.Tool.mingw
import sys
import subprocess

class ourSpawn:
    def ourspawn(self, sh, escape, cmd, args, env):
        newargs = ' '.join(args[1:])
        cmdline = cmd + " " + newargs
        stringOnlyEnv = {}
        for k, v in env.items():
            stringOnlyEnv[k] = str(v)
        proc = subprocess.Popen(cmdline, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, shell = False, env = stringOnlyEnv)
        data, err = proc.communicate()
        rv = proc.wait()
        if rv:
            print "====="
            print err
            print "====="
        return rv

def SetupSpawn( env ):
    if sys.platform == 'win32':
        buf = ourSpawn()
        buf.ourenv = env
        env['SPAWN'] = buf.ourspawn
        
def add_path(env):
    # Setup the path to the MinGW compiler
    if os.environ.has_key('MINGW_PATH'):
        compiler_path = os.environ['MINGW_PATH']
    else:
        print 'No eviroment variable MINGW_PATH was detected'
        sys.exit(1)
    env.AppendENVPath('PATH', compiler_path)
    env.Append(COMPILER_CPPPATH=[compiler_path.replace('bin', 'include')])
    env.Append(COMPILER_CPPPATH=[compiler_path.replace('bin', r'lib\gcc\mingw32\4.8.1\include')])

def generate(env):
    add_path(env)
    SCons.Tool.mingw.generate(env)
    env['CCCOM'] = "$CC -o $TARGET -c $CFLAGS $CCFLAGS $_CCCOMCOM ${SOURCES.abspath}"
    # To support long command lines use our own SPAWN to run the mingw commands
    SetupSpawn(env)

def exists(env):
    # Clone the environment so it does not get modified
    check_env = env.Clone(env)
    add_path(check_env)
    
    return SCons.Tool.mingw.exists(check_env)

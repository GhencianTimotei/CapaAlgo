import os
from SCons.Tool import Tool, createProgBuilder
from utilities import SilentTempFileMunge
from SCons.Script import Builder

def configureCompiler(env):
    c_compiler = Tool('cc')
    c_compiler(env)

    env['CC'] = 'iccavr'
    env['CCCOM']     = '$CC -o $TARGET $SOURCES $CCFLAGS'
   
def configureAssembler(env):
    assembler = Tool('as')
    assembler(env)

    env['AS'] = 'das'

    env.Append(ASFLAGS='-t$PPCTARGET')
    env.Append(ASFLAGS='-g')
    env.Append(ASFLAGS='-D__VLE')
    env.Append(ASFLAGS='-DMPC5604P')
    env.Append(ASFLAGS='-DRAM_40K')
    
def configureLinker(env):
    linker = Tool('link')
    linker(env)

    env['LINK'] = 'xlink'   
    env['TEMPFILE'] = SilentTempFileMunge
    env['LINKCOM'] = "${TEMPFILE('" + env['LINKCOM'] + ' -f $LINKER_FILE' + "')}"
    env.Append(LINKFLAGS='-c$ATTARGET')

    
    #env.Append(LIBS=['c'])
    #env.Append(LIBS=['i'])
    
    #env.Append(LINKFLAGS='-@O=$MAP_FILE')
    #env.Append(LINKFLAGS='-m30')
    

    #env['PROGSUFFIX'] = '.elf'

    def add_unused_symbol(env, symbols):
        for symbol in symbols:
            env.Append(LINKFLAGS='-u %s' % symbol)    
    env.AddMethod(add_unused_symbol, 'AddForceKeep')

def generate(env):
    compiler_path = r'c:\Program Files\IAR Systems\Embedded Workbench 6.0\avr\bin'
    env['ATTARGET'] = 'A90'
    env['TEMPFILEPREFIX'] = '-@'
    
    if os.environ.has_key('IAR_AVR_PATH'):
        compiler_path = os.environ['IAR_AVR_PATH']

    env.AppendENVPath('PATH', compiler_path)
    env.Append(COMPILER_CPPPATH=[compiler_path.replace('\\bin', '\inc')])
    env.Append(CPPPATH=env['COMPILER_CPPPATH'])
    env['OBJSUFFIX'] = '.r90'
    env['PROGSUFFIX'] = '.d90'
    configureCompiler(env)
    #configureAssembler(env)
    configureLinker(env)

    createProgBuilder(env)

    #env['BUILDERS']['ElfToSrec'] = Builder(action = '@ddump -Rv -v $SOURCE -o $TARGET', suffix='.sx')


def exists(env):
    return True

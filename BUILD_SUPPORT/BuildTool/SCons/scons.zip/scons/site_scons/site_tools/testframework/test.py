import os
import os.path
import sys
import re
import shutil
import time
import tempfile

from framework import TestFile, TestSuites, TestSuite
from resultparser import ResultParser
from subprocess import Popen, PIPE, check_output, CalledProcessError
from SCons.Script import BUILD_TARGETS
from gcov_parser import Gcov
from aspyte import Template
from SCons.Script.SConscript import global_exports

def filter_test_suite_ouput(output):
    regex_failed_test = re.compile('^(FAILED\(.*?\) )build\\\\(.*?)_.*?_stripped(.*?)$', (re.DOTALL | re.MULTILINE))
    new_output = ""
    for m in regex_failed_test.finditer(output):
        new_output += "%s%s%s\n" % (m.group(1), m.group(2), m.group(3))
         
    if new_output == "":
        sys.stdout.write(output)
    else:
        sys.stdout.write(new_output)

def testsuite_action(target, source, env):
    
    # General setup of information
    generated_dir = os.path.join(env['REPORT_DIR'].abspath, 'generated')
    report_dir = env['REPORT_DIR'].abspath
    testsuitePath = os.path.splitext(target[0].abspath)[0]
    testsuiteName = os.path.split(testsuitePath)[1]
    test_profile = env['TEST_PROFILE'][testsuiteName]
    test_profile_str = ''

    # Call the testsuite executable
    try:
        test_suite_ouput = ""
        dir = os.path.split(target[0].abspath)[0]
        if not 'TEST_OUTPUT' in env or env['TEST_OUTPUT'] != 'short':
            test_suite_ouput = check_output(target[0].abspath, cwd=dir)
        else:
            test_suite_ouput = check_output([target[0].abspath, "-v"], cwd=dir)
        
        # Filter the output and print it
        filter_test_suite_ouput(test_suite_ouput)
    except CalledProcessError, e:
        sys.stdout.write('TestSuite returned an error.')
        return e.returncode

    # Parse the result file
    resultFile = testsuitePath + '-Results.xml'
    rp = ResultParser()
    testsuite = env['TESTSUITES'].suites[testsuiteName]
    rp.parse(resultFile, testsuite)
    if not 'TEST_OUTPUT' in env or env['TEST_OUTPUT'] != 'short':
        sys.stdout.write(testsuite.tostring())

    # Copy the result file to the report directory
    if not os.path.exists(generated_dir):
        os.mkdir(generated_dir)
    
    resultFileName = os.path.split(resultFile)[1]
    
    shutil.copyfile(resultFile, os.path.join(generated_dir,
                                             resultFileName))

    # Run code coverage analysis
    if not 'TEST_OUTPUT' in env or env['TEST_OUTPUT'] != 'short':
        output = '-' * 79 + '\n'
        output += 'Code Coverage Analysis\n'
        output += '-' * 79 + '\n'
    else:
        output = ""
    gcov_files = []
    gcov_env = os.environ
    gcov_env['LANG'] = 'en_GB.UTF-8'
    
    _temp_TestsuiteName = testsuiteName.replace("test_", "").replace("_", " ")
    if _temp_TestsuiteName[0].islower():
        friendlyTestsuiteName = _temp_TestsuiteName.capitalize()
    else:
        friendlyTestsuiteName = _temp_TestsuiteName.replace("Test", "")

    if test_profile is not None:
        test_profile_str = "_%s" % test_profile
        tmpDirPrefix = "%s_%s" % (testsuiteName, test_profile)
    else:
        tmpDirPrefix = testsuiteName
        
    gcov_result_dir = tempfile.mkdtemp("", tmpDirPrefix, env['VARIANT_DIR'])

    for gcov_object in testsuite.gcov_objects:
        objname = gcov_object.data[0].name
        source_path = str(gcov_object.data[0].sources[0])
        source_name = os.path.split(source_path)[1]

        gcov = env.WhereIs('gcov')
        
        obj_file_abs_path = os.path.abspath(str(gcov_object.data[0]))
        obj_file_rel_path = os.path.relpath(obj_file_abs_path, gcov_result_dir)
        source_abs_path = os.path.abspath(source_path)
        source_rel_path = os.path.relpath(source_abs_path, gcov_result_dir)

        #gCovCmdTest = "GCOV_TEST: %s -o %s %s\n" % (str(gcov), obj_file_rel_path, source_rel_path) 
        #sys.stdout.write(gCovCmdTest)
        
        # Run gcov and get console output and file output
        gcovConsoleOutput = check_output([gcov, "-o", obj_file_rel_path, source_rel_path], env=gcov_env, cwd=gcov_result_dir)
        
        # Gcov file handling
        # ------------------
        # Gcov might generate in the same folder as the source file
        # if using MingwGCC 3.4.5 and if using 4.5.0 it generates
        # in the current working directory
        # Here we have a new working directory for each file generated
        # therefore we expect to use such a GCOV version as 4.5.0
        old_gcov_output = os.path.join(gcov_result_dir, source_name + '.gcov')
        if not os.path.exists(old_gcov_output):
            raise Exception("Maybe wrong GCOV version: can not open %s" % (old_gcov_output))
        source_path_no_ext = os.path.splitext(source_path)[0]
        gcov_output = "%s%s_TEST.c.gcov" % (os.path.join(env['VARIANT_DIR'], source_path_no_ext.replace(os.path.commonprefix([os.getcwd(),source_path_no_ext]),'')),
                                      test_profile_str)

        print "OLD %s\nNEW: %s\n" %(old_gcov_output, gcov_output)            
        
        shutil.copyfile(old_gcov_output, gcov_output)
        
        # Gcov consle output handling and coverage from .gcov-file
        # --------------------------------------------------------
        match = re.search('Lines\sexecuted:(\d+\.\d+)\%\sof\s(\d+)', gcovConsoleOutput)
        if match is not None:
            coverage = match.groups()[0]
            linesT = match.groups()[1]
            # Look for coverage in gcov file
            with open(gcov_output) as f:
                gcov_data = f.read()
                covered_lines = re.findall(r' +\d+: +(\d+):', gcov_data)
                covered_lines_str = ','.join(covered_lines)
                total_lines = re.findall(r' +[\d#]+: +(\d+):', gcov_data)
                total_lines_str = ','.join(total_lines)

            nDots = 79 - len(objname) - len(match.groups()[0])
            if not 'TEST_OUTPUT' in env or env['TEST_OUTPUT'] != 'short':
                output += objname + '.' * nDots
                output += '%s%%\n' % match.groups()[0]
            else:
                gcda_file = os.path.splitext(str(gcov_object.data[0]))[0] + ".gcda"
                gcda_file = os.path.abspath(gcda_file)
                output += "TEST SUITE (%s) COVERAGE(%s): %s%%\n" % (friendlyTestsuiteName, gcda_file, match.groups()[0])
        else:
            print "ERROR: Failed getting gcov result for %s" % (target[0])
            return 1
        
        # Create an annotated HTML version of the source file.
        gcov_parser = Gcov()
        gcov_parser.parse(gcov_output, generated_dir, test_profile)
        shutil.rmtree(gcov_result_dir)

        # Adapt the source_name if we have a test_profile
        if test_profile is not None:
            source_name = os.path.splitext(source_name)
            source_name = source_name[0] + test_profile_str + source_name[1]

        gcov_files.append((source_path, source_name, coverage, covered_lines_str, total_lines_str))

    if not 'TEST_OUTPUT' in env or env['TEST_OUTPUT'] != 'short':
        output += '\n' + '=' * 79 + '\n'
    sys.stdout.write(output)

    # Generate code coverage file report
    templatefile = os.path.join(os.path.dirname(__file__) ,
                                'templates',
                                'coverage_suite.template')
    template = Template(templatefile)
    context = {'files': gcov_files}
    output = open(os.path.join(generated_dir, testsuiteName + '-Coverage.xml'), 'w')
    output.write(template.process(context))
    output.close()

    # Check if all tests are run and print a summary of the results
    env['TESTSUITES'].built_suite_targets.append(testsuiteName)
    allbuilt = True
    for testsuite in env['TESTSUITES'].suite_targets:
        if testsuite in BUILD_TARGETS or 'test_all' in BUILD_TARGETS or '.' in BUILD_TARGETS:
            if testsuite not in env['TESTSUITES'].built_suite_targets:
                allbuilt = False
                break
    if allbuilt:
        sys.stdout.write(env['TESTSUITES'].summary())

        # Generate unittest report
        context = {'suites': env['TESTSUITES'].suite_targets,
                   'date': time.strftime('%a %b %d %H:%M:%S %Y')}

        templatefile = os.path.join(os.path.dirname(__file__) ,
                                    'templates',
                                    'unittest_report.template')
        template = Template(templatefile)
        output = open(os.path.join(report_dir, 'Unittest.xml'), 'w')
        output.write(template.process(context))
        output.close()

    	# check if the format folder exists
    	# if not, copy it from testframework location, to report location
        # the following code, it will assume that if the format folder exists
        # all the necessary files for fomratting are there
        
        formatDirDest = os.path.join(env['REPORT_DIR'].abspath, 'format')
        formatDirSource = os.path.join(os.path.abspath(''), 'scons\\site_scons\\site_tools\\testframework\\format')
        
        if not os.path.exists(formatDirDest):
           shutil.copytree(formatDirSource, formatDirDest)       
        
    return 0

def testsuite_generator(target, source, env):
    
    # Generate the testsuite runner file.
    templatefile = os.path.join(os.path.dirname(__file__) ,
                                'templates',
                                'cunit.template')
    
    TestFile(source[0].abspath, target[0].abspath, templatefile, env['TEST_PROFILE'], target[1].abspath)
    return None

def _convertToSConstructRelativePath(env, path):
    # Get SConstruct path
    scPath = env.Dir('#.').srcnode().abspath
    
    # get real path of path
    currRelativePath = env.Dir('.').srcnode().path
    currSrcDir = os.path.join(scPath, currRelativePath)
    path = os.path.join(currSrcDir, path)
    
    # get the relative path to SConstruct path
    path = '#'+ os.path.relpath(path, scPath)
    return path

def _addIncPath(env, src):
    incPath = (os.path.split(src)[0]).replace('/', '\\')
    # Find relative paths
    if incPath != "":
        if not incPath.startswith('#'):
            # convert relative paths to SConstruct relative paths
            incPath = _convertToSConstructRelativePath(env, incPath)
            
        if incPath not in env['CPPPATH']:
            env.Append(CPPPATH=[incPath])

def testsuite_method(env, testfilename, test_sources, add_sources=[], test_profile=None):
    test_profile_cflags = None
    test_profile_str = ''
    objSuffix = ''

    target = os.path.splitext(testfilename)[0]

    if test_profile is not None:
        if not isinstance(test_profile, str):
            # the test profile given for this test suite is not a string
            raise Exception("The test profile given for this test suite is not a string.") 
        test_profile = test_profile.strip().upper()
        test_profile_str = "_%s" % test_profile
        objSuffix = "_%s%s" % (test_profile, env['OBJSUFFIX'])
        # Append the profile to the target name
        target = "%s_%s" % (target, test_profile)
        
        # Find the CFLAGS for the test profile
        for profile in env['TEST_PROFILES']:
            if profile['name'] == test_profile:
                test_profile_cflags = profile['cflags']
                break
        
        # check that we did find a profile
        if test_profile_cflags is None:
            # we did not find any profile.
            raise Exception("There is no test profile defined named '%s'. Define it in SConstruct." % test_profile) 

    
    (target_directory, target_name) = os.path.split(target)
    generated_testrunner_file = os.path.join(target_directory, target_name + '_testsuite_runner.c')
    stripped_testcase_file = os.path.join(target_directory, target_name + '_stripped.c')     
    testcase_and_runner_files = env.GenerateTestSuite([generated_testrunner_file, stripped_testcase_file], testfilename, TEST_PROFILE=test_profile)
    
    templatefile = os.path.join(os.path.dirname(__file__) ,
                                'templates',
                                'cunit.template')
    frameworkFile = os.path.join(os.path.dirname(__file__) ,
                                'framework.py')
    env.Depends(generated_testrunner_file, templatefile)
    env.Depends(generated_testrunner_file, __file__)
    env.Depends(generated_testrunner_file, frameworkFile)
    env.Depends(stripped_testcase_file, __file__)
    env.Depends(stripped_testcase_file, frameworkFile)
    
    objs = []
    # Build the Test suite and test suite runner
    for src in testcase_and_runner_files:
        
        # If we are using a test profile, add the cflags to the 
        # compilation of the test cases and runner.
        # A object suffix is not needed since we have different file names
        if test_profile is not None:
            tmp = env.Object(src, CFLAGS=test_profile_cflags)
        else:
            tmp = env.Object(src)
        objs.append(tmp)
    
    # Build the Unit Under Test with GCOV options
    gcovObjs = []
    for src in test_sources:
        
        # Add the path to the source under test as include path.
        _addIncPath(env, src)

        # Some test cases need include files in the folder of the 
        # test code. Add this to the include path
        currRelativePath = env.Dir('.').srcnode().path
        testFolder = '#' + os.path.join(currRelativePath, os.path.split(testfilename)[0])
        env.Append(CPPPATH=[testFolder])

        # Create the object 
        # Compile the source under test with code coverage analysis.
        gcovCflags = '-fprofile-arcs -ftest-coverage '
        
        # if we are using a test profile, add the cflags to the 
        # compilation of the unit under test and a OBJ suffix
        if test_profile is not None:
            gcovCflags += test_profile_cflags
            gcovObj = env.Object(src, CFLAGS=gcovCflags, OBJSUFFIX=objSuffix)
        else:
            gcovObj = env.Object(src, CFLAGS=gcovCflags)
        gcovObjs.append(gcovObj)

    # add all the gcovObjs to the list of objs
    objs.extend(gcovObjs)
    
    # Build additional sources
    addObjs = []
    for src in add_sources:
        # Add the path to the additional source as include path.
        _addIncPath(env, src)

        # Create object from source
        if src[0] == "#":
            src = '#' + env['VARIANT_DIR'] + '/' + src[1:]

        # if we are using a test profile, add the cflags to the 
        # compilation of the unit under test and a OBJ suffix
        if test_profile is not None:
            tmp = None
            buildPath = env.File(src).path
            obj_key = "%s_%s" % (buildPath, test_profile)
            # check if dict has key
            if obj_key in env['TEST_OBJS']:
                tmp = env['TEST_OBJS'][obj_key]
            else:
                tmp = env.Object(src, CFLAGS=test_profile_cflags, OBJSUFFIX='STUB_' + objSuffix)
                # if not already in dictionary store it
                env['TEST_OBJS'][obj_key] = tmp
        else:
            tmp = env.Object(src)
        addObjs += tmp

    # Put the program together
    program = env.Program(target, objs + addObjs)
    
    env.Clean(program, [target + '-Results.xml', target + '-Listing.xml'])
    for src in test_sources:
        # If the test_profile is not None then
        # the test_profile_str is not empty
        env.Clean(program, [os.path.splitext(src)[0] + test_profile_str + '_TEST.gcno',
                            os.path.splitext(src)[0] + test_profile_str + '_TEST.gcda',
                            os.path.splitext(src)[0] + test_profile_str + '_TEST.c.gcov'])
    
    env['TEST_PROFILE'][target_name] = test_profile
    env.AddPostAction(program, env.Action(testsuite_action, 'Running test...'))

    # Add alias for the test cases.
    env.Alias(target_name, program)
    env.Alias('test_all', program)
    
    # Alias for running the selected test case from Eclipse
    env.Alias('{}.{}'.format(os.path.basename(testfilename), test_profile), program) 

    # Add the testsuite to the environment
    if not env.Dictionary().has_key('TESTSUITES'):
        env.Append(TESTSUITES=TestSuites())
    env['TESTSUITES'].suite_targets.append(target_name)
    testsuite = TestSuite()
    testsuite.source_file = testfilename
    testsuite.gcov_objects = gcovObjs
    env['TESTSUITES'].suites[target_name] = testsuite

def testprofile_method(env, testprofile_name, compiler_options):
    if not isinstance(testprofile_name, str):
        raise Exception("The test profile name specified is not a string")
    if not isinstance(compiler_options, str):
        raise Exception("The compiler options specified for the test profile is not a string")

    testprofile_name = testprofile_name.strip().upper()
    if testprofile_name == 'ALL':
        raise Exception('The test profile name ALL is a reserved profile name')
    for profile in env['TEST_PROFILES']:
        if testprofile_name == profile['name']:
            raise Exception("The test profile name '%s' is already in use" % testprofile_name)
    
    dict = {'name':testprofile_name, 'cflags':compiler_options}
    env['TEST_PROFILES'].append(dict)

/*
 * trace.c
 *
 *  Created on: 17 nov 2010
 *      Author: mikael.arvids
 */

#include "Trace.h"

#include <stdlib.h>

static Trace_t* head = NULL;
static Trace_t* tail = NULL;

void Trace_clear(void)
{
    Trace_t* next;

    while (head != NULL) {
        next = head->pNext;
        free(head->strMsg);
        free(head);
        head = next;
    }
    head = NULL;
    tail = NULL;
}

void Trace_add(const char* strMsg, const char* strFile, unsigned int line,
        CU_Test* pTest, unsigned int nFails)
{
    Trace_t* new = malloc(sizeof(Trace_t));

    new->strMsg = malloc(strlen(strMsg) + 1);
    strcpy(new->strMsg, strMsg);
    new->strFile = strFile;
    new->line = line;
    new->pTest = pTest;
    new->nFails = nFails;
    new->pNext = NULL;

    if(head == NULL) {
        head = new;
    }

    if (tail != NULL) {
        tail->pNext = new;
    }
    tail = new;
}

Trace_t* Trace_get(void)
{
    return head;
}


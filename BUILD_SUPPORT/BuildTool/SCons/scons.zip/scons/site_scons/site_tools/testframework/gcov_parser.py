import re
import os
from aspyte import Template

class Gcov:
    def __init__(self):
        self.re_source = re.compile('0:Source:(.+)')
        self.re_lines = re.compile('#####:\s*(\d+):')

    def parse(self, filename, output_dir, test_profile):
        gcov_input = ''.join(open(filename, 'r').readlines())

        # Get the source.
        source_file = self.re_source.search(gcov_input).groups()[0]
        source_name = os.path.split(source_file)[1]
        try:
            f = open(source_file, 'r')
            source_code = ''.join(f.readlines())
        except IOError as (errno, strerror):
            print "I/O error in '{2}' ({0}): {1}".format(errno, strerror, __file__)
        except:
            print "Unexpected error:", sys.exc_info()[0]
            raise

        # Get the lines that were not executed.
        lines_not_executed = [int(d) for d in self.re_lines.findall(gcov_input)]

        # Generate the HTML page.
        templatefile = os.path.join(os.path.dirname(__file__) ,
                                    'templates',
                                    'coverage_source.template')
        template = Template(templatefile)
        context = {'source_file': source_file,
                   'source_code': source_code,
                   'lines_not_executed': lines_not_executed}
        if test_profile is not None:
            source_name = os.path.splitext(source_name)
            test_profile_str = "_%s" % test_profile
            output = open(os.path.join(output_dir, source_name[0] + test_profile_str +
                                        source_name[1] + '.html'), 'w')
        else:
            output = open(os.path.join(output_dir, source_name + '.html'), 'w')
        output.write(template.process(context))
        output.close()

from xml.etree.ElementTree import ElementTree
from framework import TestCase

class ResultParser():
    def parse(self, filename, testsuite):
        self.xml = ElementTree(file=filename)
        iter = self.xml.getiterator('CUNIT_RUN_SUITE_SUCCESS')
        for node in iter:
            testsuite.name = node.find('SUITE_NAME').text.strip()
            break

        self.failed = []
        iter = self.xml.getiterator('CUNIT_RUN_TEST_FAILURE')
        for node in iter:
            testcase = TestCase()
            testcase.name = node.find('TEST_NAME').text.strip()
            testcase.file = node.find('FILE_NAME').text.strip()
            testcase.line = node.find('LINE_NUMBER').text.strip()
            testcase.condition = node.find('CONDITION').text.strip()
            testcase.passed = False
            testsuite.testcases.append(testcase)

            self.failed.append(testcase)
        self.numOfFailed = len(self.failed)

        self.passed = []
        iter = self.xml.getiterator('CUNIT_RUN_TEST_SUCCESS')
        for node in iter:
            testcase = TestCase()
            testcase.name = node.find('TEST_NAME').text.strip()
            testcase.passed = True
            testsuite.testcases.append(testcase)

            self.passed.append(testcase)
        self.numOfPassed = len(self.passed)

if __name__ == '__main__':
    rp = ResultParser('test_module-Results.xml')
    print rp.tostring()

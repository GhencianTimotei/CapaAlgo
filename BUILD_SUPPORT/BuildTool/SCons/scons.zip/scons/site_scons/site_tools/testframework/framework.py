import re
import os.path
from string import join, replace
from aspyte import Template

class TestFile:
    keywords = ['TEST_SUITE',
                'ADD_FILE']

    def __init__(self,
            filename=None,
            outputfile=None,
            templatefile=None,
            testProfile=None,
            testCaseFileOutput=None):
        self.filename = filename
        self.testcases = []
        self.testsuite = None
        self.testProfile = testProfile

        
        # If a filename is supplied, parse it immediately.
        if self.filename is not None:
            self.parseTestCaseFile(self.filename, self.testProfile, testCaseFileOutput)
            if outputfile is not None and templatefile is not None:
                self.generateTestSuiteRunner(outputfile, templatefile)
        

    def parseTestCaseFile(self, filename, testProfile=None, testCaseFileOutput=None):
        
        self.filename = filename
        if testProfile:
            testProfile = testProfile.upper()
        self.testProfile = testProfile
        result = self._findDirectives(filename, testProfile, testCaseFileOutput)
        self.directives = result['directives']
     
        self._warnAboutDisabledTests(result['disabled_directives'])

        self.testcases = self._getDirective(self.directives, 'TEST')
        self.testcases += self._getDirective(self.directives, 'TEST_W_PROFILES')
        
        self.testsuite = self._getDirective(self.directives, 'TEST_SUITE')[0]
        if testProfile:
            self.testsuite += "_" + testProfile

        self.add_files = []
        add_files = self._getDirective(self.directives, 'ADD_FILE')
        pathToTest = os.path.split(filename)[0]
        for add_file in add_files:
            if len(os.path.split(add_file)[0]) == 0:
                self.add_files.append(os.path.join(pathToTest, add_file))
            else:
                self.add_files.append(add_file)

        if ('TEST_SUITE_SETUP' in self.directives) or \
                      ('SETUP' in self.directives):
            self.hasTestSuiteSetup = True
        else:
            self.hasTestSuiteSetup = False

        if ('TEST_SUITE_TEARDOWN' in self.directives) or \
                      ('TEARDOWN' in self.directives):
            self.hasTestSuiteTeardown = True
        else:
            self.hasTestSuiteTeardown = False

        if ('TEST_CASE_SETUP' in self.directives) or \
                ('TEST_SETUP' in self.directives):
            self.hasTestCaseSetup = True
        else:
            self.hasTestCaseSetup = False

        if ('TEST_CASE_TEARDOWN' in self.directives) or \
                ('TEST_TEARDOWN' in self.directives):
            self.hasTestCaseTeardown = True
        else:
            self.hasTestCaseTeardown = False
            
    def _warnAboutDisabledTests(self, directivesList):
        # Get relative path of source file
        fileRelative = os.path.relpath(self.filename)
        
        # Find the disabled tests for each section
        for directivesAndLine in directivesList:
            line = directivesAndLine[0]
            directives = directivesAndLine[1]  
            testCases = self._getDirective(directives, 'TEST')
            testCases += self._getDirective(directives, 'TEST_W_PROFILES')
            
            testCaseString = ""
            for testCase in testCases[:-1]:
                testCaseString += "%s, " % (testCase)
            testCaseString += str(testCases[-1])
            
            print "%s:%d:1: warning: disabled test cases: %s" % (fileRelative, line, testCaseString)

    def generateTestSuiteRunner(self, outputfile, templatefile):
        template = Template(templatefile)

        targetPath = os.path.split(outputfile)[0]
        resultoutput = replace(os.path.join(targetPath,
            os.path.splitext(os.path.split(self.filename)[1])[0]),
            '\\', '\\\\')
        if self.testProfile:
            resultoutput += "_" + self.testProfile
        
        testsource = replace(os.path.relpath(self.filename), '\\', '\\\\')

        context = {'testcases': self.testcases,
                   'testsuite': self.testsuite,
                   'hasTestSuiteSetup': self.hasTestSuiteSetup,
                   'hasTestSuiteTeardown': self.hasTestSuiteTeardown,
                   'hasTestCaseSetup': self.hasTestCaseSetup,
                   'hasTestCaseTeardown': self.hasTestCaseTeardown,
                   'testoutput': resultoutput,
                   'testsource': testsource}

        output = open(outputfile, 'w')
        output.write(template.process(context))
        output.close()

    def _findDirectives(self, filename, testProfile=None, testCaseFileOutput=None):
        directives = []
        keywords = join(self.keywords, '|')
        regex_testcases = re.compile('(TEST|TEST_W_PROFILES)\(\s*(\w+)\s*,*\s*\({0,1}\s*((?:,*\s*\w+\s*)*)\s*\){0,1}\s*\)', re.DOTALL)
        regex_curlparant_left = re.compile('\{', re.DOTALL)
        regex_curlparant_right = re.compile('\}', re.DOTALL)
        regex_directives = re.compile('(' + keywords + ')\(\s*([\"\w\.,\s]+)\s*\)', re.DOTALL)
        regex_setup_teardown = re.compile('^\s*(SETUP|TEARDOWN|TEST_SETUP|TEST_TEARDOWN|'+
                                          'TEST_SUITE_SETUP|TEST_SUITE_TEARDOWN|'+
                                          'TEST_CASE_SETUP|TEST_CASE_TEARDOWN).*?\{', re.DOTALL | re.MULTILINE)
        regex_comments = re.compile('(/\*.*?\*/|//.*?(?=\n))', re.DOTALL)
        regex_disabled_sections = re.compile('DISABLE_BEGIN(.*?)DISABLE_END', re.DOTALL)
        #regex_lines_before_dis_sec = re.compile('(.*?)DISABLE_BEGIN', re.DOTALL)
        regex_line_count = re.compile('\r\n|\r|\n', re.DOTALL)

        input = join(open(filename).readlines(), '')

        # Remove all comments
        new_input = ""
        last_pos = 0
        for m in regex_comments.finditer(input):
            start = m.start()
            # Add section before match
            new_input += input[last_pos:start]
            # Add any new lines in match
            new_lines = regex_line_count.findall(m.group(0))
            new_input += ''.join(new_lines)
            last_pos = m.end()

        # Add any section after last match and use new input
        new_input += input[last_pos:]
        input = new_input

        # Find all disabled sections to be able to warn
        last_pos = 0
        last_line = 0
        disabled_directives = []
        for m in regex_disabled_sections.finditer(input):
            start = m.start()
            line_count = regex_line_count.findall(input[last_pos:start]) 
            last_line += len(line_count)
            lineno = last_line + 1
            last_pos = start + 1
            disabled_section = m.group(1)
            section_with_directives = regex_testcases.findall(disabled_section) # Find all disabled test cases
            dis_directives_and_line = (lineno, section_with_directives) 
            disabled_directives.append(dis_directives_and_line)

        # Remove all disabled sections
        input = regex_disabled_sections.sub('', input) 
        # Find all directives
        directives += regex_directives.findall(input)
        # Check for setup and teardown of test suites
        directives += regex_setup_teardown.findall(input)

        ###################################
        # Check for test cases and create a new test case file.
        #############
        # TODO: Rewrite the below code to get it to be a nicer
        # state machine
        
        # Split into lines to work test case by test case.
        input = input.splitlines(True)
        
        # Open output file of new file with stripped test cases
        testCaseFile = None
        if testCaseFileOutput:
            testCaseFile = open(testCaseFileOutput, 'w')
        
        copyLine = True
        includeTestCase = True
        leftCurlCount = 0
        rightCurlCount = 0
        insideTestCase = False
        
        atLineAfterTestCase = False
        
        for line in input:
            # Try to find a test case
            testCase = regex_testcases.match(line)

            # This is to start copying the lines after the
            # test case but not the last line of the test case
            # that contains the curl.
            if atLineAfterTestCase:
                atLineAfterTestCase = False
                copyLine = True
            
            # find all curly parentheses to see where test case ends.
            if insideTestCase: 
                leftCurlParent = regex_curlparant_left.findall(line) 
                rightCurlParent = regex_curlparant_right.findall(line)
                leftCurlCount += len(leftCurlParent)
                rightCurlCount += len(rightCurlParent)
                
                if leftCurlCount > 0 and ((leftCurlCount - rightCurlCount) == 0):
                    # We have found at least that the first left curl and as many
                    # right curls as left curls. We have a balanced number of curls
                    # therefore we are outside the test case.
                    # reset
                    insideTestCase = False
                    leftCurlCount = 0
                    rightCurlCount = 0
                    
                    # we want to copy the lines that are between test cases
                    # but not the line with the curl on
                    atLineAfterTestCase = True
                         
            if testCase is not None:
                insideTestCase = True
                parsedTestcase = None
                
                # Check if we should include this test case
                # it depends on the profile
                if testCase.lastindex == 3 and testCase.group(3) is not '':
                    # we have one or more profiles specified
                    profiles = testCase.group(3).split(',')
                    strippedProfiles = []
                    for profile in profiles:
                        tempProfile = profile.strip().upper()
                        if len(tempProfile) > 0:
                            strippedProfiles.append(tempProfile)
                    
                    profiles = strippedProfiles
                    
                    parsedTestcase = (testCase.group(1), testCase.group(2), profiles)

                    # Check if any profiles where actually given
                    if len(profiles) > 0:
                        # Check if we have the None profile
                        # then we should only include test with
                        # the ALL profile and tests without the
                        # any profile 
                        if testProfile is None:
                            if 'ALL' in profiles:
                                includeTestCase = True
                            else:
                                includeTestCase = False
                        else:
                            # The test profile is not None
                            # Check that the test cases has the correct profile
                            # specified or that the magic ALL profile is given.                                                            
                            if any(testProfile in profile_str for profile_str in profiles) or 'ALL' in profiles:
                                includeTestCase = True
                            else:
                                includeTestCase = False
                    else:
                        # No profile is specified.
                        # We should only include this test case if we
                        # have the None profile
                        if testProfile is None:
                            includeTestCase = True
                        else:
                            includeTestCase = False
                else:
                    # No profile is specified.
                    # We should only include this test case if we
                    # have the None profile
                    parsedTestcase = testCase.groups()
                    
                    if testProfile is None:
                        includeTestCase = True
                    else:
                        includeTestCase = False
                        
                        
                if includeTestCase:
                    copyLine = True
                    directives.append(parsedTestcase)
                    #print "inc: %s" % str(parsedTestcase)
                else:
                    copyLine = False
                    #print "exc: %s" % str(parsedTestcase)

            if testCaseFile and copyLine:
                testCaseFile.write(line)
            if testCaseFile and (copyLine == False):
                testCaseFile.write("\n")

        if testCaseFile:                 
            testCaseFile.close()

        return {'directives': directives, 'disabled_directives': disabled_directives}

    def _getDirective(self, all_directives, name):
        directives = []
        for directive in all_directives:
            if directive[0] == name:
                directives.append(directive[1].strip(' "'))
        return directives

class TestSuites:
    def __init__(self):
        self.suite_targets = []
        self.built_suite_targets = []
        self.suites = {}

    def summary(self):
        numFailed = 0
        numPassed = 0

        failedSuites = []
        for suite in self.suites:
            for testcase in self.suites[suite].testcases:
                if testcase.passed:
                    numPassed += 1
                else:
                    numFailed += 1
                    if not suite in failedSuites:
                        failedSuites.append(suite)

        output = '\n' + '*' * 79 + '\n'
        output += 'Test results\n'
        output += '-' * 79 + '\n'
        output += 'Suites:    %d / %d\n' % (len(self.built_suite_targets),
                                           len(self.suites))
        output += 'TestCases: %d (%d passed / %d failed) \n' % ((numFailed + numPassed),
                                                                (numPassed),
                                                                (numFailed))

        if len(failedSuites) > 0:
            output += '\nFailed TestSuites\n'
            output += '-' * 79 + '\n'
            for suite in failedSuites:
                output += '%s (in %s)\n' % (self.suites[suite].name,
                                            self.suites[suite].source_file)

        output += '\n' + '*' * 79 + '\n\n'

        return output

class TestSuite:
    def __init__(self):
        self.name = None
        self.source_file = None
        self.testcases = []
        self.add_sources = []

    def tostring(self):
        output = '\n' + '=' * 79 + '\n'
        output += 'TestSuite %s\n' % self.name
        output += '-' * 79 + '\n'
        for testcase in self.testcases:
            output += testcase.tostring()
        output += '\n'
        return output

class TestCase:
    def __init__(self):
        self.name = None
        self.file = None
        self.line = None
        self.condition = None
        self.passed = None

    def tostring(self):
        output = ''
        if self.passed:
            nDots = 80 - len(self.name) - len('passed') - 1
            output += '%s%spassed\n' % (self.name, '.'*nDots)
        else:
            nDots = 80 - len(self.name) - len('FAILED') - 1
            output += '%s%sFAILED\n' % (self.name, '.'*nDots)
            output += '    File:      %s(%s)\n' % (self.file, self.line)
            output += '    Condition: %s\n' % self.condition
        return output

if __name__ == "__main__":
    TestFile('PowerTest.c', 'PowerTest_testsuite_runner.c',
              'templates\\cunit.template', None, None)
    

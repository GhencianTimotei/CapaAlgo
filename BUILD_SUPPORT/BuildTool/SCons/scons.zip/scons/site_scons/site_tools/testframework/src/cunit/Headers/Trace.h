/*
 * trace.h
 *
 *  Created on: 17 nov 2010
 *      Author: mikael.arvids
 */

#ifndef TRACE_H_
#define TRACE_H_

#include "CUnit.h"

typedef struct Trace_s
{
    char* strMsg;
    const char* strFile;
    unsigned int line;
    CU_Test* pTest;
    unsigned int nFails;
    struct Trace_s* pNext;
} Trace_t;

extern void Trace_clear(void);

extern void Trace_add(const char* strMsg, const char* strFile,
        unsigned int line, CU_Test* pTest, unsigned int nFails);
extern Trace_t* Trace_get(void);

#endif /* TRACE_H_ */

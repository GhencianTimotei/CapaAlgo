/**
 * @file TestFramework.h
 * @brief This file should be included in each file that contains test cases.
 */

#include "Automated.h"
#include <stdio.h>
#include "TestRun.h"
#include "Trace.h"

#define TEST(testcase)                      void test_ ## testcase(void)
#define TEST_W_PROFILES(testcase, profiles)    TEST(testcase)
#define TEST_SUITE_SETUP                    int test_suite_setup(void)
#define TEST_SUITE_TEARDOWN                 int test_suite_teardown(void)
#define TEST_CASE_SETUP                     void test_case_setup(void)
#define TEST_CASE_TEARDOWN                  void test_case_teardown(void)

/* The macros below are for backwards comaptibility with the previous
 * version of this framework used in the INVP project. */
#define SETUP                   TEST_SUITE_SETUP
#define TEARDOWN                TEST_SUITE_TEARDOWN
#define TEST_SETUP              TEST_CASE_SETUP
#define TEST_TEARDOWN           TEST_CASE_TEARDOWN

#define DISABLE_BEGIN
#define DISABLE_END

#define ADD_FILE(filename)
#define TEST_SUITE(testsuite)
#define DESCRIPTION(description)

#define SETUP_SUCCESS   (0)
#define SETUP_FAILED   (-1)

#define TEARDOWN_SUCCESS    SETUP_SUCCESS
#define TEARDOWN_FAILED     SETUP_FAILED

#define TEST_MESSAGE_MAX	1024

static char test_message_buf[TEST_MESSAGE_MAX];

#ifdef DISABLE_TRACE
#define TRACE(msg)
#else
#define TRACE(msg) Trace_add(msg, __FILE__, __LINE__, CU_get_current_test(), CU_get_number_of_failure_records());
#endif

/* Assert macro mapping. Add more if required. */
#define TEST_ASSERT_FLOAT_EQUAL(a, b) \
    do { \
        float actual_a = (a); \
        float actual_b = (b); \
        snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_INT_EQUAL: Expected that %s(%I64d) == %s(%I64d)", #a, actual_a, #b, actual_b); \
        CU_assertImplementation((actual_a == actual_b), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
    } while (0)

#define TEST_ASSERT_INT_EQUAL(a, b) \
	do { \
		long long int actual_a = (a); \
		long long int actual_b = (b); \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_INT_EQUAL: Expected that %s(%I64d) == %s(%I64d)", #a, actual_a, #b, actual_b); \
		CU_assertImplementation((actual_a == actual_b), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
	} while (0)

#define TEST_ASSERT_INT_EQUAL_FATAL(a, b) \
    do { \
        long long int actual_a = (a); \
        long long int actual_b = (b); \
        snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_INT_EQUAL_FATAL: Expected that %s(%I64d) == %s(%I64d)", #a, actual_a, #b, actual_b); \
        CU_assertImplementation((actual_a == actual_b), __LINE__, test_message_buf, __FILE__, "", CU_TRUE);\
    } while (0)

#define TEST_ASSERT_INT_NOT_EQUAL(a, b) \
	do { \
		long long int actual_a = (a); \
		long long int actual_b = (b); \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_INT_NOT_EQUAL: Expected that %s(%I64d) != %s(%I64d)", #a, actual_a, #b, actual_b); \
		CU_assertImplementation((actual_a != actual_b), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
	} while (0)

#define TEST_ASSERT_INT_GREATER_THAN(a, b) \
    do { \
        long long int actual_a = (a); \
        long long int actual_b = (b); \
        snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_INT_GREATER_THANL: Expected that %s(%I64d) > %s(%I64d)", #a, actual_a, #b, actual_b); \
        CU_assertImplementation((actual_a > actual_b), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
    } while (0)

#define TEST_ASSERT_PTR_EQUAL(a, b) \
	do { \
		void* actual_a = (a); \
		void* actual_b = (b); \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_PTR_EQUAL: Expected that %s(0x%p) == %s(0x%p)", #a, actual_a, #b, actual_b); \
		CU_assertImplementation((actual_a == actual_b), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
	} while (0)

#define TEST_ASSERT_PTR_NOT_EQUAL(a, b) \
	do { \
		void* actual_a = (a); \
		void* actual_b = (b); \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_PTR_NOT_EQUAL: Expected that %s(0x%p) != %s(0x%p)", #a, actual_a, #b, actual_b); \
		CU_assertImplementation((actual_a != actual_b), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
	} while (0)

#define TEST_ASSERT_PTR_NULL(ptr) \
	do { \
		void* actual_ptr = (ptr); \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_PTR_NULL: Expected that %s(0x%p) == NULL", #ptr, actual_ptr); \
		CU_assertImplementation((NULL == actual_ptr), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
	} while (0)

#define TEST_ASSERT_PTR_NOT_NULL(ptr) \
	do { \
		void* actual_ptr = (ptr); \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_PTR_NOT_NULL: Expected that %s(0x%p) != NULL", #ptr, actual_ptr); \
		CU_assertImplementation((NULL != actual_ptr), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
	} while (0)

#define TEST_ASSERT_STRING_EQUAL(a, b) \
	do { \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_STRING_EQUAL: Expected that %s(\"%s\") == %s(\"%s\")", #a, (const char*)(a), #b, (const char*)(b)); \
		CU_assertImplementation(!(strcmp((const char*)(a), (const char*)(b))), __LINE__, "test", __FILE__, "", CU_FALSE);\
	} while (0)


#define TEST_ASSERT_STRING_NOT_EQUAL(a, b) \
	do { \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_STRING_NOT_EQUAL: Expected that %s(\"%s\") != %s(\"%s\")", #a, (const char*)(a), #b, (const char*)(b)); \
		CU_assertImplementation((strcmp((const char*)(a), (const char*)(b))), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
	} while (0)


#define TEST_ASSERT_NSTRING_EQUAL(a, b, n) \
	do { \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_STRING_EQUAL: Expected that %s(\"%s\") == %s(\"%s\")", #a, (const char*)(a), #b, (const char*)(b)); \
		CU_assertImplementation(!(strncmp((const char*)(a), (const char*)(b), n)), __LINE__, "test", __FILE__, "", CU_FALSE);\
	} while (0)

#define TEST_ASSERT_NSTRING_NOT_EQUAL(a, b, n) \
	do { \
		snprintf(test_message_buf, TEST_MESSAGE_MAX, "TEST_ASSERT_STRING_NOT_EQUAL: Expected that %s(\"%s\") != %s(\"%s\")", #a, (const char*)(a), #b, (const char*)(b)); \
		CU_assertImplementation((strcmp((const char*)(a), (const char*)(b), n)), __LINE__, test_message_buf, __FILE__, "", CU_FALSE);\
	} while (0)


/* The ASSERT macros below are kept for backwards compatibility
 * with test written in the INVP project
 */
#define TEST_ASSERT CU_ASSERT
#define TEST_IGNORE(msg)
#define TEST_ASSERT_MESSAGE(value, msg) CU_ASSERT(value)
#define TEST_INT_EQUAL(x, y)					\
  if (x != y)							\
    printf("PRE ASSERT: %s(%d) != %s(%d)\n", #x, (x), #y, (y));	\
  TEST_ASSERT(x == y)
#define TEST_INT_NOT_EQUAL(x, y)				\
  if (x == y)							\
    printf("PRE ASSERT: %s(%d) == %s(%d)\n", #x, (x), #y, (y));	\
  TEST_ASSERT(x != y)

#define	TEST_PASS_MESSAGE(msg)	CU_PASS(msg)

#define	TEST_FAIL_MESSAGE(msg)	CU_FAIL(msg)

import os
from SCons.Tool import Tool, createProgBuilder, createObjBuilders
from utilities import SilentTempFileMunge
from SCons.Script import Builder
from subprocess import Popen, PIPE, STDOUT
import SCons.Defaults
import SCons.Tool
import SCons.Util

ASSuffixes = ['.s87']

def configureAssembler(env):
    a_assembler = Tool('as')
    a_assembler(env)

    env['AS'] = 'arl78.exe'
    env['ASCOM']     = '$AS -o $TARGET $SOURCES $ASFLAGS'
    
def configureCompiler(env):
    
    c_compiler = Tool('cc')
    c_compiler(env)
    root_dir = os.getcwd()
    
    # Add include paths for IAR compiler
    for dir_name in env['APPL_INCLUDES']:
        dir_name=dir_name.replace('/','\\')
        dir_name = dir_name[2:]
        dir_abs_path = '\"'+ dir_name + '\"'
	env.Append(CCFLAGS='-I '+ dir_abs_path)

    env['CC'] = 'iccrl78.exe'
    env['CCCOM']     = '$CC -o $TARGET $SOURCES $CCFLAGS'
  
    
def configureLinker(env):
    linker = Tool('link')
    linker(env)
    env['LINK'] = 'xlink'   
    env['TEMPFILE'] = SilentTempFileMunge          
            
    env['LINKCOM']     = '$LINK -o $TARGET $LINKER_FILE $LINKFLAGS'
    def add_unused_symbol(env, symbols):
        for symbol in symbols:
            env.Append(LINKFLAGS='-u %s' % symbol)    
    env.AddMethod(add_unused_symbol, 'AddForceKeep')

def generate(env):
    static_obj, shared_obj = SCons.Tool.createObjBuilders(env)
    for suffix in ASSuffixes:
        static_obj.add_action(suffix, SCons.Defaults.ASAction)
        static_obj.add_emitter(suffix, SCons.Defaults.StaticObjectEmitter)
        
    compiler_path = 'c:\Program Files (x86)\IAR Systems\Embedded Workbench 7.0\rl78\bin'
    
    if os.path.isdir(compiler_path) == False:
        compiler_path= 'c:\Program Files (x86)\IAR Systems\Embedded Workbench 7.0_0\rl78\bin'
    
    env['TEMPFILEPREFIX'] = '-@'
    
    if os.environ.has_key('COMPILER_PATH'):
        compiler_path = os.environ['COMPILER_PATH']
    else:
        print 'No eviroment variable COMPILER_PATH was detected'
        sys.exit(1)    



    
    env.AppendENVPath('PATH', compiler_path)
    #env.Append(COMPILER_CPPPATH=[compiler_path.replace('\bin', '\inc')])
    #env.Append(CPPPATH=env['COMPILER_CPPPATH'])
    
    
    
    configureCompiler(env)
    configureAssembler(env)
    configureLinker(env)
    env['OBJSUFFIX'] = '.r87'
    env['PROGSUFFIX'] = '.d87'
    createProgBuilder(env)

def exists(env):
    return True

import os
import sys
import os.path
import re
from subprocess import check_output
from testframework.test import testsuite_method, testsuite_generator, testprofile_method

def getGcovVersion(env):
    gcovBin = env.WhereIs('gcov')
    gcovVersionInfo = check_output([gcovBin, "-v"])
    match = re.search('\d\.\d.\d', gcovVersionInfo)
    if match is not None:
        return match.group(0)
    else:
        return None

def generate(env):
    # Change the object file suffix to avoid collision with main build.
    env['OBJSUFFIX'] = '_TEST.o'

    env.Append(CPPPATH=['#scons/site_scons/site_tools/testframework/src'])
    env.Append(CPPPATH=['#scons/site_scons/site_tools/testframework/src/cunit/Headers'])

    # Add the required libraries
    env.Append(LIBPATH=['#scons/site_scons/site_tools/testframework/src/cunit'])
    env.Append(LIBS=['cunit', 'gcov'])
    
    # Create storage for test profiles information
    env['TEST_PROFILES'] = []
    
    # Create a dictionary to store what every test suite has as profile
    env['TEST_PROFILE'] = {}
    
    # Create a storage for objects hashtable to avoid creating the same
    # object multiple times. Maybe needed because of problem in SCons when using OBJSUFFIX?
    env['TEST_OBJS'] = {}
    
    env['GCOV_VERSION'] = getGcovVersion(env)
    
    # Setup the unittest builder.
    env.AddMethod(testsuite_method, 'TestSuite')
    env.AddMethod(testprofile_method, 'TestProfile')
    testSuiteGenerator = env.Builder(action=env.Action(testsuite_generator,
                                                   'Generating testsuite files...'))
    
    env.Append(BUILDERS={'GenerateTestSuite' : testSuiteGenerator})
    
    reportsDir = env['VARIANT_DIR']+ '/cunit_tests_reports'
    if not os.path.exists(reportsDir):
       os.mkdir(reportsDir)
    
    env['REPORT_DIR'] = env.Dir(reportsDir)

def exists(env):
    return True

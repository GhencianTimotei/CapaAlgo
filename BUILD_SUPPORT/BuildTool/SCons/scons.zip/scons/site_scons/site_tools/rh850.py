import os
from SCons.Tool import Tool, createProgBuilder, createObjBuilders
from utilities import SilentTempFileMunge
from SCons.Script import Builder
import SCons.Defaults
import SCons.Tool
import SCons.Util

ASSuffixes = ['.850']

def configureAssembler(env):
    a_assembler = Tool('as')
    a_assembler(env)
    # Add include paths for Assembler
    root_dir = os.getcwd()
    for dir_name in env['APPL_INCLUDES']:
        dir_name=dir_name.replace('/','\\')
        dir_name = dir_name[1:]                      
	dir_abs_path = root_dir + '\\'+ dir_name
	env.Append(CCFLAGS='-I '+dir_abs_path)

    env['AS'] = 'ccv850.exe'
    env['ASCOM']     = '$CC $CCFLAGS -o $TARGET -filetype.assembly $SOURCES'
        	
def configureCompiler(env):
    
    c_compiler = Tool('cc')
    c_compiler(env)    
    # Add include paths for compiler
    root_dir = os.getcwd()
    for dir_name in env['APPL_INCLUDES']:
        dir_name=dir_name.replace('/','\\')
        dir_name = dir_name[1:]                      
	dir_abs_path = root_dir + '\\'+ dir_name
	env.Append(CCFLAGS='-I '+dir_abs_path)

    env['CC'] = 'ccv850.exe'
    env['CCCOM']     = '$CC $CCFLAGS -filetype.c $SOURCES -o $TARGET'
      
def configureLinker(env):
	linker = Tool('link')
	linker(env)            
	env['LINK'] = 'ccv850.exe'
	env['TEMPFILE'] = SilentTempFileMunge
	env['LINKCOM']     = '$LINK -o $TARGET $SOURCES $LINKER_FILE $LLFLAGS $LINKFLAGS'

def generate(env):
    static_obj, shared_obj = SCons.Tool.createObjBuilders(env)
    for suffix in ASSuffixes:
        static_obj.add_action(suffix, SCons.Defaults.ASAction)
        static_obj.add_emitter(suffix, SCons.Defaults.StaticObjectEmitter) 
       
    env['TEMPFILEPREFIX'] = '-@'    
    if os.environ.has_key('COMPILER_PATH'):
        compiler_path = os.environ['COMPILER_PATH']
        print compiler_path
    else:
        print 'No eviroment variable COMPILER_PATH was detected'
        sys.exit(1)    
    env.AppendENVPath('PATH', compiler_path)
    
    configureCompiler(env)
    configureAssembler(env)
    configureLinker(env)
    env['OBJSUFFIX'] = '.o'
    env['PROGSUFFIX'] = ''
    createProgBuilder(env)

def exists(env):
    return True

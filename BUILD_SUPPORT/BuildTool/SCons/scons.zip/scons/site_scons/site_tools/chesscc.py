import os
from SCons.Tool import Tool, createProgBuilder, createObjBuilders
from utilities import SilentTempFileMunge
from SCons.Script import Builder

def configureAssembler(env):
    a_assembler = Tool('as')
    a_assembler(env)    
    # Add include paths for Assembler
    root_dir = os.getcwd()
    for dir_name in env['APPL_INCLUDES']:
        dir_name=dir_name.replace('/','\\')
        dir_name = dir_name[1:]                      
	dir_abs_path = root_dir + '\\'+ dir_name
	env.Append(CCFLAGS='-I '+dir_abs_path)

    env['AS'] = 'chesscc.exe'
    env['ASCOM']     = '$CC $CCFLAGS -o $TARGET $SOURCES'
        	
def configureCompiler(env):
    
    c_compiler = Tool('cc')
    c_compiler(env)    
    # Add include paths for compiler
    root_dir = os.getcwd()
    for dir_name in env['APPL_INCLUDES']:
        dir_name=dir_name.replace('/','\\')
        dir_name = dir_name[1:]                      
	dir_abs_path = root_dir + '\\'+ dir_name
	env.Append(CCFLAGS='-I '+dir_abs_path)

    env['CC'] = 'chesscc.exe'
    env['CCCOM']     = '$CC $CCFLAGS -o $TARGET $SOURCES $DARTS_OPTIONS $NOODLE_OPTIONS '
      
def configureLinker(env):
	linker = Tool('link')
	linker(env)            
	env['LINK'] = 'chesscc.exe'
	env['TEMPFILE'] = SilentTempFileMunge
	env['LINKCOM']     = '$LINK -o $TARGET $SOURCES $LLFLAGS $DARTS_OPTIONS $LINKFLAGS $LINKER_FILE'

def generate(env):
       
    env['TEMPFILEPREFIX'] = '-@'    
    if os.environ.has_key('TARGET_COMPILER_CHESS'):
        compiler_path = os.environ['TARGET_COMPILER_CHESS']
    else:
        print 'No eviroment variable TARGET_COMPILER_CHESS was detected'
        sys.exit(1)    
    env.AppendENVPath('PATH', compiler_path)

    configureCompiler(env)
    #configureAssembler(env)
    configureLinker(env)
    env['OBJSUFFIX'] = '.o'
    env['PROGSUFFIX'] = ''
    createProgBuilder(env)

def exists(env):
    return True

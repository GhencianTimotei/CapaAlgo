import os
from SCons.Tool import Tool, createProgBuilder, createObjBuilders
from utilities import SilentTempFileMunge
from SCons.Script import Builder

def configureAssembler(env):
	assembler = Tool('as')
	assembler(env)
	env['AS'] = 'a78k0r.exe'
	env.Append(ASFLAGS='--core=78k0r')
	env.Append(ASFLAGS='-D__FAR_MODEL__')
	env.Append(ASFLAGS='-D__NEAR_DATA_MODEL__')
    
def configureCompiler(env):
    
    c_compiler = Tool('cc')
    c_compiler(env)
    root_dir = os.getcwd()
    
    # Add include paths for IAR compiler
    for dir_name in env['APPL_INCLUDES']:
        dir_name=dir_name.replace('/','\\')
        dir_name = dir_name[1:]                      
	dir_abs_path = root_dir + '\\'+ dir_name
	env.Append(CCFLAGS='-I '+dir_abs_path)

    env['CC'] = 'icc78k0r.exe'
    env['CCCOM']     = '$CC -o $TARGET $SOURCES $CCFLAGS'
  
    
def configureLinker(env):
    linker = Tool('link_long_cmd')
    linker(env)
    env['LINK'] = 'xlink'   
    env['TEMPFILE'] = SilentTempFileMunge
    env['LINKCOM'] = "${TEMPFILE('" + env['LINKCOM'] + ' -f $LINKER_FILE' + "')}"
    
  

    def add_unused_symbol(env, symbols):
        for symbol in symbols:
            env.Append(LINKFLAGS='-u %s' % symbol)    
    env.AddMethod(add_unused_symbol, 'AddForceKeep')

def generate(env):
       
    env['TEMPFILEPREFIX'] = '-@'
    
    if os.environ.has_key('IAR_78K0R_PATH'):
        compiler_path = os.environ['IAR_78K0R_PATH']
    else:
        print 'No eviroment variable IAR_78K0R_PATH was detected'
        sys.exit(1)

    
    env.AppendENVPath('PATH', compiler_path)
    #env.Append(COMPILER_CPPPATH=[compiler_path.replace('\bin', '\inc')])
    #env.Append(CPPPATH=env['COMPILER_CPPPATH'])
    
    
    
    configureCompiler(env)
    configureAssembler(env)
    configureLinker(env)
    env['OBJSUFFIX'] = '.r26'
    env['PROGSUFFIX'] = '.d26'
    createProgBuilder(env)

def exists(env):
    return True

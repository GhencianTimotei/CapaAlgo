from SCons.Defaults import DefaultEnvironment
from SCons.Script import AddOption
from SCons.Script.SConsOptions import SConsValues

# Prevent SCons from searching for tools.
DefaultEnvironment(tools=[])

#==============================================================================#
# Classes
#==============================================================================#
from SCons.Platform import TempFileMunge
from SCons import Action

class SilentTempFileMunge(TempFileMunge):
    """ This class is used instead of TempFileMunge for skipping the output.
    """
    def __call__(self, target, source, env, for_signature):
        stored_print_actions = Action.print_actions
        Action.print_actions = False
        retval = TempFileMunge.__call__(self, target, source, env, for_signature)
        Action.print_actions = stored_print_actions
        return retval
    
def gen_file_from_template(target_file, template_file, subst_dict):
    template = open(template_file).read()
    for key in subst_dict:
        template = template.replace('%%%s%%' % key, subst_dict[key])
    open(target_file, 'w').write(template)